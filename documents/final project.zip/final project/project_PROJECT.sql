-- MySQL dump 10.13  Distrib 5.7.12, for osx10.9 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PROJECT`
--

DROP TABLE IF EXISTS `PROJECT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROJECT` (
  `pid` int(11) NOT NULL,
  `Pname` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `tag` varchar(45) DEFAULT NULL,
  `samples` blob,
  `min_fund` int(11) DEFAULT NULL,
  `max_fund` int(11) DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `comp_time` datetime DEFAULT NULL,
  `pstatus` varchar(45) DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROJECT`
--

LOCK TABLES `PROJECT` WRITE;
/*!40000 ALTER TABLE `PROJECT` DISABLE KEYS */;
INSERT INTO `PROJECT` VALUES (1,'tennis','I want to buy a tennis court','jazz',NULL,100,2000,'2017-01-01 00:00:00','2018-01-01 00:00:00','close','2017-01-01 00:00:00'),(2,'NeedMoney','I want some money','jazz',NULL,100,200,'2017-01-01 00:00:00','2017-05-05 00:00:00','close','2017-01-02 00:00:00'),(3,'Savelife','Need your kind help!','hospital',NULL,100,500,'2019-01-01 00:00:00',NULL,'pending','2017-02-03 00:00:00'),(4,'Dance','I like jazz ! Need your help!','Dance',NULL,20,900,'2019-01-01 00:00:00',NULL,'pending','2017-02-05 00:00:00'),(5,'Keep Healthy','Jazz can help you keep fit!','Dance',NULL,40,1000,'2018-04-06 00:00:00',NULL,'pending','2017-03-04 00:00:00'),(6,'NYU','Tandon','Ny',NULL,321,4411,'2019-01-04 00:00:00',NULL,'pending','2017-04-06 00:00:00'),(7,'Hospital','cure','cure',NULL,1000,4000,'2018-01-01 00:00:00',NULL,'pending','2017-06-05 00:00:00'),(8,'House','For living','residence',NULL,200,5000,'2018-01-04 00:00:00',NULL,NULL,'2017-07-04 00:00:00'),(9,'9th fund','test','jazz',NULL,50,1200,'2017-02-01 00:00:00','2017-05-05 00:00:00',NULL,'2017-04-01 00:00:00'),(10,'testcase10','great','jazz',NULL,1000,2000,'2017-03-04 00:00:00','2017-09-05 00:00:00',NULL,NULL);
/*!40000 ALTER TABLE `PROJECT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-20 11:30:57
